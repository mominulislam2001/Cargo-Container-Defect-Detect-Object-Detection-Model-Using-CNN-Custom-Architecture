# CDD_3classes_detection > damage_tracking_3_classes_yolov8
https://universe.roboflow.com/sedawy-work-space/cdd_3classes_detection

Provided by a Roboflow user
License: CC BY 4.0

